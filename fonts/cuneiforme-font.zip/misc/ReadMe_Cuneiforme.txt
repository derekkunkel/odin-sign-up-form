_____________________________________________________________________

Cuneiforme

Version 2.00 

Copyright (c) 2010 Juan Casco. All Rights Reserved.
http://www.juancascofonts.blogspot.com/
metanorocker14@hotmail.com
_____________________________________________________________________

Description:
.........i supossed it doesnt need of it

Conditions of use:

1. The designer as well as owner of this font is Juan Casco

2. This is a free font, but it is restricted to personal use only. Commercial use may be obtained by paying a licensing fee.

3. This font may not be included in any commercial compilation of fonts, be it on CD, disks or other products, without the owner's permission.

4. This font may not be used for commercial ends and financial gain without the owner's permission.

5. This font may be freely distributed, as long as the zipfile, including this text, remains unaltered.


For comercial use , please write to metanorocker14@hotmail.com
